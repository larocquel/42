#include <stdlib.h>
#include <stdio.h>

typedef struct  s_point
  {
    int           x;
    int           y;
  }               t_point;
void  fill(char **tab, t_point size, int currx, int curry, char beginchar);
void  flood_fill(char **tab, t_point size, t_point begin)
{
	char beginchar = tab[begin.y][begin.x];
	fill(tab, size, begin.x, begin.y, beginchar);
}
void  fill(char **tab, t_point size, int currx, int curry, char beginchar)
{
	//{0, -1}, {-1,  0}, {+1,  0}, {0, +1},
	if ((currx >= 0 && currx < size.x && curry >= 0 && curry < size.y) && tab[curry][currx] == beginchar)
	{
		tab[curry][currx] = 'F';

		fill(tab, size, currx, curry -1, beginchar);
		fill(tab, size, currx - 1, curry, beginchar);
		fill(tab, size, currx + 1, curry, beginchar);
		fill(tab, size, currx, curry +1, beginchar);
	}
}

