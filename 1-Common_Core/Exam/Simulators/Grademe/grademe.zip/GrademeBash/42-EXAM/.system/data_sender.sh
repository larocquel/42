#!/bin/bash
userpost="user=$LOGNAMELOG42EXAM"
os="os=$(uname)"
date=$(date '+%F_%H:%M:%S')
time="time=$date"

usingpost="using=$1"


